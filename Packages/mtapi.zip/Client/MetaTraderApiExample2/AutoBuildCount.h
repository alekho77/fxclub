// 1
#ifndef AUTOBUILDCOUNT_H
#define AUTOBUILDCOUNT_H
#define BUILDCOUNT_NUM 1
#define BUILDCOUNT_STR "1"
#endif
